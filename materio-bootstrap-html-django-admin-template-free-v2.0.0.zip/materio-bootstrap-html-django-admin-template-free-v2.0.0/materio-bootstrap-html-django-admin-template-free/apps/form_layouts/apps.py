from django.apps import AppConfig


class FormlayoutsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.form_layouts"
